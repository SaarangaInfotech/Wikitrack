package com.saaranga.wikitrack.utilities;

public class PreferenceSupplier {

}
